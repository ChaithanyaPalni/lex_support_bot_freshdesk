var request = require('sync-request');
var PreProcess = require('./src/preprocess.js')
exports.handler = (event, context, callback) => {
    try {
        console.log("event log : " + JSON.stringify(event));
		var bypass = (process.env.BYPASS === 'true');
		if(!bypass){
			var p_event = new PreProcess(event);
			var intent_dir= p_event.intent;
			var intent_file = require("./intents/" +intent_dir+"/"+ p_event.intent + ".js");
			callback(null,intent_file(p_event));
		}else {
			var params = {
				headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(event)
			}
			var response = request("POST", process.env.LOCAL_HOST, params);
			callback(null, JSON.parse(response.getBody('utf-8')));
		}
    } catch (err) {
        callback(err);
    }
};
