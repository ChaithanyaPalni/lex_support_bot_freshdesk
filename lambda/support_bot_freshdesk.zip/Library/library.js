//var restcall = require('./restcall.js');
function library_actions(){

    this.get_the_high_priority_slot_from_new_slots = function(p_event,new_slots){
        var intent_dir= p_event.intent;
        var slots_order = require("./../intents/" +intent_dir+"/slot_flow.json");
        console.log('Slots flow '+ JSON.stringify(slots_order));
        console.log('New slots are '+ JSON.stringify(new_slots));
        var required_new_slot = {};
        for (var i = 0; i <= slots_order.length - 1; i++) {
            for (var j = 0; j <= new_slots.length - 1; j++) {
                if (slots_order[i].name === new_slots[j]) {
                    var new_slot = slots_order[i];
                    if (required_new_slot.priority) {
                        if (new_slot.priority < required_new_slot.priority) {
                            required_new_slot = new_slot;
                        }
                    } else {
                        required_new_slot = new_slot;
                    }
                }
            }
        }
        return required_new_slot;
    };

    this.getNewSlotInfo = function(p_event,new_slot){
        var intent_dir= p_event.intent;
        var slots_order = require("./../intents/" +intent_dir+"/slot_flow.json");
        for(var i=0; i<=slots_order.length-1; i++){
            if(new_slot === slots_order[i].name){
                return slots_order[i] ;
            }
        }       
    };
    
    this.formatCasevariables = function(slot,value, formatter,intent_name){
        var slotArr =[];
    	var path = '../intents/'+ intent_name+ '/'+ slot + '.json';
    	console.log(path);
    	slotArr = require(path);
    	
    	if(!slotArr || slotArr.length <=0){slotArr =[];}

    	var response_card = [];
    	if(slotArr && slotArr.length>0){
    		for(var i=0; i<slotArr.length; i++){
    		    if(formatter ==="name"){
    		        if(slotArr[i].name == value){
    		            return slotArr[i].value;
    		        }
    		    }else{
    		        if(slotArr[i].value == value){
    		            return slotArr[i].name;
    		        }    		        
    		    }
    		}
    	}
    }

    this.validateContactNumber = function(contactNumber){
        // Added By Praveen : to validate phone number
        var phoneRe = /^[2-9]\d{2}[2-9]\d{2}\d{4}$/;
        var digits = contactNumber.replace(/\D/g, "");
        return phoneRe.test(digits);
    };

    this.easyToReadDate = function(date){
        var weekdays = new Array(7);
        weekdays[0] = "Sunday";
        weekdays[1] = "Monday";
        weekdays[2] = "Tuesday";
        weekdays[3] = "Wednesday";
        weekdays[4] = "Thursday";
        weekdays[5] = "Friday";
        weekdays[6] = "Saturday";
        var easyToReadDate = "on " + date;
        var today = new Date();
        var todayDay = today.getDay();
        var givenDate = new Date(date);
        var day = givenDate.getDay();
        var diff = ((givenDate.getTime() - today.getTime()) / 1000);
        diff = Math.floor(diff / 86400);
        console.log('Diff: ' + diff + ':: Day: ' + day);
        if (diff == 1) {
            easyToReadDate = 'tomorrow';
        } else if (diff == 2) {
            easyToReadDate = 'day after tomorrow';
        } else if (diff > 2 && diff <= 6 - todayDay) {
            easyToReadDate = 'coming ' + weekdays[day];
        } else if (diff > 6 - todayDay && diff <= 6 + todayDay) {
            easyToReadDate = 'next ' + weekdays[day];
        } else {
            return easyToReadDate;
        }
        console.log('date: ' + easyToReadDate);
        return easyToReadDate;
    };
    
    
    this.getSlotResponseCard = function(intent_name,slot){
        
    var responseCard= {
      "version": 1,
      "contentType": "application/vnd.amazonaws.card.generic",
      "genericAttachments": [] 
    };
        
    	var slotArr =[];
    	var path = '../intents/'+ intent_name+ '/'+ slot + '.json';
    	console.log(path);
    	slotArr = require(path);
    	
    	if(!slotArr || slotArr.length <=0){slotArr =[];}

    	var response_card = [];
    	if(slotArr && slotArr.length>0){
    		for(var i=0; i<slotArr.length; i++){
    			var responseObj ={};
    			responseObj.title = slotArr[i].name;
    			responseObj.subTitle = slotArr[i].name;
    			responseObj.buttons = [{
    			    "text": slotArr[i].name,
    			    "value": slotArr[i].value
    			}];
    			response_card.push(responseObj);
    		}
    	}
    	responseCard.genericAttachments = response_card;
    	return responseCard;
    };
}
module.exports =new library_actions;
