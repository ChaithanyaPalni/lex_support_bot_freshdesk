var middleware = require('./../../middleware/middleware.js');
var library = require('./../../Library/library.js');

module.exports = function (p_event) {
	var current_slot_state = true;
	var new_slots = p_event.getFreshSlots(p_event);
	console.log('The fresh slots are ::: ' + JSON.stringify(new_slots));
	var new_slot = new_slots[0];

	if (!new_slot && p_event.getContext()['elicitSlot']) {
		new_slot = p_event.getContext()['elicitSlot'];
		p_event.updateSlot(new_slot, p_event.inputTranscript);
	}
	if (p_event.event.intent.confirmationStatus != "None") {
		new_slot = 'confirm';
	}
	if(!new_slot){new_slot='intent_init';}
	var new_slots_copy = JSON.parse(JSON.stringify(new_slots));
	var next_action;
	if (new_slots && new_slots.length > 0) {
		for (var i = 0; i <= new_slots.length - 1; i++) {
			var priority_slot = library.get_the_high_priority_slot_from_new_slots(p_event,new_slots_copy);
			console.log('Priority slot is '+ JSON.stringify(priority_slot));
			next_action =  eval("set_"+priority_slot.name)(p_event);
			new_slots_copy =new_slots_copy.splice(new_slots_copy.indexOf(priority_slot), 1);
			if (!current_slot_state) {
				return next_action;
			}
		}
		return next_action;
	} else {
			return  eval("set_"+new_slot)(p_event); 
	}
};

function set_case(p_event){
	var case_Info =middleware.getActiveCases();
	console.log('Cases info '+ JSON.stringify(case_Info));
	var response  = getCasesResponse(case_Info);
	p_event.clearFilledSlots();
    return p_event.dispatch().elicitIntent(response.message, response.responseCard );
}


function getCasesResponse(cases){
	var responseCard= {
      "version": 1,
      "contentType": "application/vnd.amazonaws.card.generic",
      "genericAttachments": [] 
    };
	
	if(cases && cases.length>0){
		for(var i=0; i<=cases.length-1; i++){
			var obj ={
				"title": cases[i].subject,
				"subTitle": cases[i].description_text,
				 "buttons":[ 
	                 {
	                    "text":cases[i].description_text,
	                    "value":cases[i].id
	                 }
                 ]
			};
			responseCard.genericAttachments.push(obj);
		}
		console.log('Response card is '+ JSON.stringify(responseCard));
		return {
			"message": "You have "+ cases.length + " active cases. Here is the info. ",
			"responseCard": responseCard
		};
	}else{
		return {
			"message": "You do not have any active cases.",
			"responseCard": null
		};
	}
}