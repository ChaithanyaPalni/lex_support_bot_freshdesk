var middleware = require('./../../middleware/middleware.js');
var library = require('./../../Library/library.js');
var freshdesk_config = require('./../../middleware/freshdesk_config.json');

module.exports = function (p_event) {
	var current_slot_state = true;
	var new_slots = p_event.getFreshSlots(p_event);
	console.log('The fresh slots are ::: ' + JSON.stringify(new_slots));
	var new_slot = new_slots[0];

	if (!new_slot && p_event.getContext()['elicitSlot']) {
		new_slot = p_event.getContext()['elicitSlot'];
		p_event.updateSlot(new_slot, p_event.inputTranscript);
	}
	if (p_event.event.intent.confirmationStatus != "None") {
		new_slot = 'confirm';
	}
	if(!new_slot){new_slot='intent_init';}
	var new_slots_copy = JSON.parse(JSON.stringify(new_slots));
	var next_action;
	if (new_slots && new_slots.length > 0) {
		for (var i = 0; i <= new_slots.length - 1; i++) {
			var priority_slot = library.get_the_high_priority_slot_from_new_slots(p_event,new_slots_copy);
			console.log('Priority slot is '+ JSON.stringify(priority_slot));
			next_action =  eval("set_"+priority_slot.name)(p_event);
			new_slots_copy =new_slots_copy.splice(new_slots_copy.indexOf(priority_slot), 1);
			if (!current_slot_state) {
				return next_action;
			}
		}
		return next_action;
	} else {
			return  eval("set_"+new_slot)(p_event); 
	}
};

function set_case(p_event){
	p_event.pushFilledSlots('case');
	return p_event.dispatch().elicitSlot('case_id',"Please provide the case id.");
}

function set_case_id(p_event){
	current_slot_state = true;
	var case_Info =middleware.getCaseStatus(p_event.getSlots()['case_id']);
	if(case_Info && case_Info.id){
		p_event.pushFilledSlots('case_id');
	    var statusResponseCard = library.getSlotResponseCard('Amz_Update_Case_status','case_status');
	    return p_event.dispatch().elicitSlot('case_status',"Please provide the updated status for the case. ", statusResponseCard);
	}else{
		return p_event.dispatch().elicitSlot('case_id',"Can not find any information with the case id, you have provided. Please provide the correct case id");
	}
}


function set_case_status(p_event){
	current_slot_state = true;
	var case_Info =middleware.getCaseStatus(p_event.getSlots()['case_id']);
	var case_obj ={
		  "priority" : case_Info.priority,
		  "requester_id" :freshdesk_config.end_user_id ,
		  "source" : 7,
		  "status" :parseInt(p_event.getSlots()['case_status']),
		  "subject" :case_Info.subject,
		  "type" : case_Info.type,
		  "description" : case_Info.description,
		  "name": freshdesk_config.name,
		  "email": freshdesk_config.email
	};
  
		console.log('Case Obj '+ JSON.stringify(case_obj));
		var updateCaseStatus = middleware.updateCaseStatus(case_obj,p_event.getSlots()['case_id']);
    	p_event.clearFilledSlots();
  		return p_event.dispatch().elicitIntent("Your case status updated successfully. " );
}


