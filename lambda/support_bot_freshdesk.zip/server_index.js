var PreProcess = require('./src/preprocess.js')
module.exports.handler = function(event){
	var p_event = new PreProcess(event);
	var intent_dir= p_event.intent;
	var intent_file = require("./intents/" +intent_dir+"/"+ p_event.intent + ".js");
	return intent_file(p_event);
}
