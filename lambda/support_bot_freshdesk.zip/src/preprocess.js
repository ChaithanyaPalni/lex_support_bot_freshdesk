var AWSEvent = require('./aws_event.js');
var AWSDispatch = require('./aws_dispatch.js');
function PreProcess(event) {
	var aws_event = new AWSEvent(event);
	var aws_dispatch = new AWSDispatch(aws_event);
	this.inputTranscript = aws_event.inputTranscript;

	this.event = aws_event;
	this.intent = event.currentIntent.name;

	this.getSessionAttributes = function(){
		return this.event.session.sessionAttributes();
	}

	this.getSession = function(){
		return this.event.session.session();
	}

	this.getSlots= function(){
		//let slots = aws_event.intent.slots();
		//let context = this.event.session.session().context.getContext();
		//for(var slot in slots){
		//	if(context[slot] != null){
		//		slots[slot] = context[slot];
		//		this.updateFilledSlot(slot, slots[slot]);
		//	}
		//}
		//return slots;
		return this.event.getSlots()
	}
	this.updateSlot = function(slot_key, slot_value){
		aws_event.intent.updateSlot(slot_key, slot_value);
	}

	this.getFilledSlots = function() {
		return aws_event.getFilledSlots();
	}

	this.getFreshSlots= function(){
		return aws_event.getFreshSlots();
	}

	this.pushFilledSlots = function(slot_key){
		this.event.session.session().filledSlots.pushSlot(slot_key);
	}
	this.popFilledSlots = function(slot_key){
		this.event.session.session().filledSlots.popSlot(slot_key);
	}
	this.clearFilledSlots = function(){
		this.event.session.session().filledSlots.clearFilledSlots();
	}

	this.getContext= function(){
		return this.event.session.session().context.getContext();
	}

	this.updateContext = function(slot_key, slot_value){
		this.event.session.session().context.updateContext(slot_key, slot_value);
	}

	this.clearContext = function(){
		this.event.session.session().context.clearContext();
	}

	this.getDomainValues = function(key){
		console.log("domain values");
		return this.event.session.session().domain_values.getDomainValues(key);
	}

	this.dispatch = function(){
		return aws_dispatch;
	}

	this.addDomainValues = function(key,value){
		this.event.session.session().domain_values.addDomainValues(key,value);
	}
	this.deleteDomainValue = function(key){
		this.event.session.session().domain_values.deleteDomainValue(key);
	}

}
module.exports = PreProcess;
