function AWSDispatch(aws_event) {

	this.elicitIntent = function (message, card_data) {
		aws_event.session.session().context.updateContext("elicitSlot", null);
		return {
			sessionAttributes: aws_event.session.sessionAttributes(),
			dialogAction: {
				type: 'ElicitIntent',
				message: {
					contentType: "PlainText",
					content: message
				},
				responseCard: card_data
			}
		};
	}

	this.elicitSlot = function (slotToElicit, message, card_data) {
		aws_event.session.session().context.updateContext("elicitSlot", slotToElicit);
		console.log('Response card is '+JSON.stringify(card_data) );
		console.log('Message is :: '+ message);
		return {
			sessionAttributes: aws_event.session.sessionAttributes(),
			dialogAction: {
				type: "ElicitSlot",
				message: {
					contentType: "PlainText",
					content: message
				},
				intentName: aws_event.intent.name,
				slots: aws_event.getSlots(),
				slotToElicit: slotToElicit,
				responseCard: card_data
			}
		};
	}

	this.close = function (message, card_data) {
		return {
			dialogAction: {
				type: "Close",
				fulfillmentState: "Fulfilled",
				message: {
					contentType: "PlainText",
					content: message
				},
				responseCard: card_data
			}
		};
	}

	this.confirmIntent = function (message, card_data) {
		aws_event.session.session().context.updateContext("elicitSlot", null);
		return {
			sessionAttributes: aws_event.session.sessionAttributes(),
			dialogAction: {
				type: "ConfirmIntent",
				message: {
					contentType: "PlainText",
					content: message
				},
				intentName: aws_event.intent.name,
				slots: aws_event.getSlots(),
				responseCard: card_data
			}
		};
	}

	this.delegate = function () {
		return {
			sessionAttributes: aws_event.session.sessionAttributes(),
			dialogAction: {
				type: "Delegate",
				slots: aws_event.getSlots()
			}
		};
	}

	// responseCard = function(card_data){
	// 	let r_card = [];
	// 	card_data.forEach(function(x){
	// 		r_card.push({
	// 			title: x.title,
	// 			subTitle: x.subTitle,
	// 			imageUrl: x.imageUrl != null ? x.imageUrl :"http://smartbots.us/demobots/healthplans_billing/images/dump/service1.png",
	// 			attachmentLinkUrl: x.attachmentLinkUrl != null ? x.attachmentLinkUrl : "http://smartbots.us/demobots/healthplans_billing/images/dump/service1.png",
	// 			buttons: [{
	// 				text: x.text,
	// 				value: x.value
	// 			}]
	// 		});                          
	// 	});
	// 	return {
	// 		version: 1,
	// 		contentType: "application/vnd.amazonaws.card.generic",
	// 		genericAttachments: r_card
	// 	}
	// };		

}

module.exports = AWSDispatch;
