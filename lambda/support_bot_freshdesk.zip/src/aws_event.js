var AWSIntent = require('./aws_intent.js');
var AWSSession = require('./aws_session.js')
function AWSEvent(event){
	var aws_intent = new AWSIntent(event.currentIntent);
	var aws_session = new AWSSession(event.sessionAttributes);
	this.inputTranscript = event.inputTranscript;
	this.intent = aws_intent;
	this.session = aws_session;

	this.getIntent = function(){
		return aws_intent;
	}

	this.getSlots= function(){
		let slots = this.intent.slots();
		let context = this.session.session().context.getContext();
		for(var slot in slots){
			if(context[slot] != null){
				slots[slot] = context[slot];
				this.session.session().context.updateContext(slot, slots[slot]);
			}
		}
		return slots;
	}

	this.getFilledSlots = function(){
		var slotObjs = this.getSlots();
		var r_slots = [];
		for(var slot_obj in slotObjs){
			if(slotObjs[slot_obj] != null){
				r_slots.push(slotObjs[slot_obj].getSlot().key);
			}
		}
		return r_slots;
	}

	this.getFreshSlots = function(){
		let filled_slots = aws_intent.getFilledSlots();
		let session_filled_slots = aws_session.session().filledSlots.filledSlots;
		if(session_filled_slots.length != 0){
			return filled_slots.filter((x) => !session_filled_slots.includes(x));
		}else{
			return filled_slots;
		}
	}
}

module.exports = AWSEvent;
