var AWSSlot = require('./aws_slot.js');
function AWSIntent(currentIntent) {
	var intent_slots = currentIntent.slots;
	var confirmationStatus = currentIntent.confirmationStatus;
	this.name = currentIntent.name
	this.confirmationStatus = confirmationStatus;
	
	this.slots = function(){
		var r_slots = {};
		var slotObjs = this.slotObjs;
		for(var slot_obj in slotObjs){
			var slotObj = slotObjs[slot_obj].getSlot();
			r_slots[slotObj.key] = slotObj.value;
		}
		return r_slots;
	}

	this.updateSlot = function(slot_key,slot_value){
		var slotObj = this.slotObjs[slot_key];
		slotObj.updateSlot(slot_key,slot_value);
		console.log("slot key : " + slot_key + "updated to " + slot_value);
	}

	this.slotObjs = (function() {
		var r_slots = {};
		for(var f_slot in intent_slots){
			var aws_slot = new AWSSlot(f_slot, intent_slots[f_slot]);
			r_slots[f_slot] = aws_slot;
		}
		return r_slots;
	})();

	this.status = function() {
		console.log()
	}

	this.getFilledSlots = function(){
		var slotObjs = this.slotObjs;
		var r_slots = [];
		for(var slot_obj in slotObjs){
			if(slotObjs[slot_obj].getSlot().value != null){
				r_slots.push(slotObjs[slot_obj].getSlot().key);
			}
		}
		return r_slots;
	}
}

module.exports = AWSIntent;
