function AWSDomainValues(domain_values_arg){
	var domain_values;
	if(typeof domain_values_arg != 'undefined'){
		domain_values = JSON.parse(domain_values_arg);
	}else{
		domain_values = {};
	}

	this.getDomainValues = function(key){
		return domain_values[key] ? domain_values[key] : null;
	}
	this.addDomainValues = function(key,value){
		domain_values[key]= value;
		return domain_values;
	}
	this.deleteDomainValue = function(key){
		delete domain_values[key];
		return domain_values;
	}
	
	this.getString = function(){
		if(typeof domain_values != 'undefined'){
			return JSON.stringify(domain_values);
		}
	}	
}

module.exports = AWSDomainValues;
