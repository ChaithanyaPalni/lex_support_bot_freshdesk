function AWSSlot(slot_key, slot_value) {
	var key = slot_key;
	var value = slot_value;

	this.getSlot = function(){
		return {
			key: key,
			value: value
		}
	}

	this.updateSlot = function(s_key, s_value) {
		key = s_key;
		value = s_value;
		return this.getSlot();
	}
}
module.exports = AWSSlot;
