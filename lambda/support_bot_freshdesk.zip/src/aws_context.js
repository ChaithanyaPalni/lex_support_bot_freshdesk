function AWSContext(context_arg){
	var context;
	if(typeof context_arg != 'undefined'){
		context = JSON.parse(context_arg);
	}else{
		context = {}
	}
	
	this.getContext = function(){
		return context;
	}

	this.getString = function(){
		if(context != 'undefined'){
			return JSON.stringify(context);
		}
	}

	this.updateContext = function(slot_key, slot_value){
		context[slot_key]= slot_value;
	}

	this.clearContext = function(){
		context = {};
	}

}

module.exports = AWSContext;
