var AWSContext = require('./aws_context.js');
var AWSDomainValues = require('./aws_domain_values.js');
function AWSSession(sessionAttributes){
	var aws_context = new AWSContext(sessionAttributes.context);
	var aws_domain_values = new AWSDomainValues(sessionAttributes.domain_values);
	var aws_filled_slots = new AWSFilledSlots(sessionAttributes.filledSlots);
	var session = sessionAttributes;
	session.context = aws_context;
	session.domain_values = aws_domain_values;
	session.filledSlots = aws_filled_slots;

	this.session = function(){
		return session;
	}

	this.sessionAttributes = function(){
		var session_attributes = JSON.parse(JSON.stringify(session));
		session_attributes.context = aws_context.getString();
		session_attributes.domain_values = aws_domain_values.getString();
		session_attributes.filledSlots = aws_filled_slots.getString();
		return session_attributes;
	}

	this.clearCurrentAttributes = function(){
		if(session.currentAttributes != null){
			console.log("clearing session attributes");
			console.log("beforeeee  " + session.currentAttributes);
			session.currentAttributes = null;
			console.log("After   " +session.currentAttributes);
		}
	}
}

function AWSFilledSlots(filled_slots_arg){
	var filled_slots;
	if(typeof filled_slots_arg != 'undefined'){
		filled_slots = JSON.parse(filled_slots_arg);
	}else{
		filled_slots = [];
	}

	this.filledSlots = filled_slots;

	this.getString = function(){
		if(this.filledSlots != 'undefined'){
			return JSON.stringify(this.filledSlots);
		}
	}
	this.pushSlot = function(slot_key){
		this.filledSlots.push(slot_key);
	}

	this.popSlot = function(slot_key){
		let slot_index = this.filledSlots.indexOf(slot_key);
		if(slot_index >= 0){
			this.filledSlots.splice(slot_index, 1);
		}
	}

	this.clearFilledSlots = function(){
		this.filledSlots = [];
	}
}

module.exports = AWSSession;
