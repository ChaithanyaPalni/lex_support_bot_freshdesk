const request = require('request');
exports.handler = (event, context, callback) => {
    try {
        console.log("event log : " + JSON.stringify(event));
		request({url: 'http://ec2-100-26-100-156.compute-1.amazonaws.com:8999', method:"POST", json: event}, function(err, res, body){
		    console.log(body);
		    callback(null, body);
		});
    } catch (err) {
        callback(err);
    }
};

