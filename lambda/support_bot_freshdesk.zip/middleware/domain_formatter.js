function response_format_actions(){
    
    this.formatList = function(servicesList, domain_values){
        console.log('Domain values are '+ JSON.stringify(domain_values));
        console.log('Service list is '+ JSON.stringify(servicesList));
        var obj_keys = Object.keys(domain_values);
        var result = [];
        for(var i=0; i<=servicesList.length-1; i++){
            var obj ={};
            for(var j=0; j<=obj_keys.length-1; j++){
                obj[obj_keys[j].toString()] = servicesList[i][domain_values[obj_keys[j].toString()]];
            }
            console.log('Single Object ::: '+ JSON.stringify(obj));
            result.push(obj);
        }
        return result;
    };
    
    this.formatObject = function(serviceObj, domain_values){
        var obj_keys = Object.keys(domain_values);
        var result={};
        for(var i=0; i<=obj_keys.length-1; i++){
            result[obj_keys[i].toString()] = serviceObj[domain_values[obj_keys[i].toString()]];
        }
    };
}
module.exports =new response_format_actions;
