var restcall = require('./restcall.js');
var domain_values = require('./../middleware/domain_values.json');
var domain_formatter = require('./domain_formatter.js');
var freshdesk_config = require('./../middleware/freshdesk_config.json');

function middleware_actions(){

    this.getActiveCases =function(){
        var queryObj= {
            'url': "?include=description",
            'method':'GET'
        };
        var cases= restcall.restCall(queryObj);
        console.log('Domain values are '+domain_values );
        var case_domain_values = domain_values.ticket;
        var active_cases = domain_formatter.formatList(cases,case_domain_values);
        return active_cases;
    };

    this.getCaseStatus =function(case_id){
        var queryObj= {
            'url': '/'+case_id,   
            'method':'GET'
        };
        var case_info= restcall.restCall(queryObj);
        return case_info;
    };

    this.createCase = function(case_obj){
        var queryObj= {
            'url': '',
            'method':'post',
            'body':case_obj
        };
        var caseInfo= restcall.restCall(queryObj);
        return caseInfo;        
    };
    
    this.updateCaseStatus = function(case_obj, case_id){
        var queryObj= {
            'url': '/'+case_id,   
            'method':'put',
            'body':case_obj
        };
        var caseInfo= restcall.restCall(queryObj);
        console.log('Update case Info '+ JSON.stringify(caseInfo));
        return caseInfo;         
    };
}
module.exports =new middleware_actions;
