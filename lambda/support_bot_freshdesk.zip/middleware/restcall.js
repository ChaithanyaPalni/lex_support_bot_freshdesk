var freshdesk_config = require('./../middleware/freshdesk_config.json');
var restUrl = freshdesk_config.request_uri;


var request = require('sync-request');

function RestAPICall() {
    this.restCall = function (queryObj) {
        var uri =freshdesk_config.request_uri+ queryObj.url;
        console.log(uri);
        var body = JSON.stringify({});
        if(queryObj.body){
            body=JSON.stringify(queryObj.body);
        }
        var method = queryObj.method;
        var params={};
        if(method.toLowerCase() == 'post'){
            params= {
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization":'Basic '+ freshdesk_config.basic_token
                },
                body: body
            };
        }else if(method.toLowerCase() == 'put'){
            params= {
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization":'Basic '+ freshdesk_config.basic_token
                },
                body: body
            };            
        }
        else{
            params= {
                headers: {
                    'Content-Type': 'application/json',
                    "Authorization":'Basic '+ freshdesk_config.basic_token
                }
            };
        }         
        var response = request(queryObj.method, uri,params);
        try{
            console.log(response.getBody('utf8'));
            return JSON.parse(response.getBody('utf8'));
        }catch(e){
            return response.getBody('utf8');          
        }
    };
}
module.exports = new RestAPICall();
